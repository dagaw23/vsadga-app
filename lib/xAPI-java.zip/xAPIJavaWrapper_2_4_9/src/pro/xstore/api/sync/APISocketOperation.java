package pro.xstore.api.sync;

public enum APISocketOperation {
    READ,
    WRITE,
    CLOSE
}
