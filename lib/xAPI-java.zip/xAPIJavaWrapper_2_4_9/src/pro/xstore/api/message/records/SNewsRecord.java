package pro.xstore.api.message.records;

public class SNewsRecord extends WrapperNewsRecord {

	@Override
	public String toString() {
		return "SNewsRecord [toString()=" + super.toString() + "]";
	}
}